package com.pcs.apptoko.response.login

data class Data(
    val admin: Admin,
    val token: String
)